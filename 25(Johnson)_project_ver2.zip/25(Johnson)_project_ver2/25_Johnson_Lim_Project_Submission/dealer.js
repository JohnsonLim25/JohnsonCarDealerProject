var brandlist = new Array("Porsche","Volkswagen","Audi","BMW");


//Counter variable limiting maximum customers to 10 each time
var count = 0;

function newClient(){
	var preference = Math.floor((Math.random()*4));
	var time = Math.floor((Math.random()*10000)+1);
	
	
	//Limits the maximum number of customers to 10
	if (count < 10 ){
		var client = Math.floor((Math.random()*10)+1);
	$("#clients_queue").append('<div class="client client_'+client+ "choice_"+brandlist[preference] + '"><span class="preference">Client for '+brandlist[preference]+'</span></div>');
		
	// Include the newly served customer
		count = count + 1;
	}
	
	setTimeout(function(){newClient();},time);
}
$("document").ready(function() {
	newClient();
});
