var brandlist = new Array("Porsche","Volkswagen","Audi","BMW");

//Intialising Counter variable 
var customercounter = 0;

//Intialising clients served
var clients_served = 0;

//Intialising cars sold
var cars_sold = 0;

//Intialising the income
var amount = 0;

//Intialising brandcost
var brandcost = new Array('72,500.00', '23,930.00', '31,260.00', '43,990.00');

//Create a variable name to store future elements which will be trapped inside the variable,
//so we can store or retrieve last stored element
var vDropElement;

//Create a variable to hide the car after the car has been purchased
var vappendHideElement;

function newClient(){
	var preference = Math.floor((Math.random()*4));
	var time = Math.floor((Math.random()*10000)+1);
	
	//Limits the maximum number of customers to 10
	if (customercounter < 10 ) {
		var client = Math.floor((Math.random()*10)+1);
																		//Code to check for the choice of the client
		$("#clients_queue").append('<div class="client client_'+client+ ' choice_' + brandlist[preference] + '"><span class="preference">Client for '+brandlist[preference]+'</span></div>');
	

						
		// Include the newly served customer
		customercounter = customercounter + 1;
		// Make the 1st client draggable and revert the customer's position if not dropped
		$('#clients_queue > .client:first').draggable({ /*revert the first customer to it's orginal position*/revert:true, zIndex: 100 /* This makes the client appear above the car */ 
															}); //Code end structure for draggable client
		}
	
	setTimeout(function(){newClient();},time);
}

//Creating a general function of dropclient() with parameters
function dropclient($this, ui)
{
				//To check if a car has a client assigned
			$this.not(':has(".client")').each(function(){
				//Update the document with a draggable code
			$this.append(ui.draggable.css({
				float: 'left' }));
			//Set the draggable function posiioning of the document to left and top
			ui.draggable.position ({of: $(this), my:'left top', at:'left top'});
			
			// Additional processing to update the webpage with a new client
			customercounter = customercounter - 1;
			newClient();
			
			//Adds a class of .selected to the client purchasing a car
			ui.draggable.addClass('selected');
				});
				
} //End of dropclient() function


//Creating a general function of dropclient2() with parameters
function dropclient2($this, ui)
{
				//To check if a car has a client assigned
			$this.not(':has(".client")').each(function(){
				//Update the document with a draggable code
			$this.append(ui.draggable.css({
				float: 'left' }));
			//Set the draggable function posiioning of the document to left and top
			ui.draggable.position ({of: $(this), my:'left top', at:'left top'});
			
			//Checks if a client does not have a class of selected
			if(!ui.draggable.hasClass('selected')){
				// Additional processing to update the webpage with a new client
				customercounter = customercounter - 1;
				newClient();
			}
			
				});
				
} //End of dropclient2() function


//Creating a function to remove clients with parameters of ui & where
function removeclient(ui, where)
{
	//Adding a animation for  clients at the exit 
	ui.draggable.animate({top: where}
						//Using fadeout function to fadeout a client
						).fadeOut(function(){
						//Removes a client by fading out a client
						ui.draggable.remove();
	}); //End of fadeout effect
} //End of removeclient() function


//Creating a function to set the cost of different car brands
function calcost(ui)
{
	//Checks if the car has a class of choice_Porsche
	if(ui.draggable.hasClass('choice_Porsche'))
	{
		//Changes the cost of the car to match the index 0.
		return brandcost[0];
	}
	
	//Checks if the car has a class of choice_Volkswagen
	else if(ui.draggable.hasClass('choice_Volkswagen'))
	{
		//Changes the cost of the car to match the index 1.
		return brandcost[1];
	}
	
	//Checks if the car has a class of choice_Audi
	else if(ui.draggable.hasClass('choice_Audi'))
	{
		//Changes the cost of the car to match the index 2.
		return brandcost[2];
	}
	
	//Checks if the car has a class of choice_BMW
	else if(ui.draggable.hasClass('choice_BMW'))
	{
		//Changes the cost of the car to match the index 3.
		return brandcost[3];
	}
} //End of setting car brand pricing of calcost() function

	//Creating a function to update the clients, cars_sold, and income 
	function update() 
	{
		//Updating the clients served to the clients who are visited the car showroom
		$('#client_served').text(clients_served + 'clients');
		
		//Updating the cars sold each time a client purchases a car
		$('#cars_sold').text(cars_sold + ' cars');
		
		$('#amount').text('S$ ' + amount); //Calculate income from car sold
	} //End of update() function

//Make sure the webpages load all resources
$("document").ready(function() {
	//Creates a function called newClient()
	newClient();
	
	//Creates a function called update()
	update();
	
	//Make clients for porsche, droppable 
	$('#porsche .car').droppable({
		//Accepted choice of car which is porsche
		accept: '.choice_Porsche' ,

		//Drop the client through a function
		drop: function(e, ui) {
			dropclient($(this), ui);
			vDropElement = $(this).closest("#porsche .car");
			
		}
	}); //End of Code for droppable porsche clients
	
	//Processing for other brands
	
	//Make clients for volkswagen, droppable 
	$('#volkswagen .car').droppable({
		//Accepted choice of car which is porsche
		accept: '.choice_Volkswagen' ,
		
		//Drop the client through a function
		drop: function(e, ui) {
			dropclient($(this), ui);
			vDropElement = $(this).closest("#volkswagen .car");
			
		}
	}); //End of Code for droppable volkskwagen clients
	
	//Make clients for audi, droppable 
	$('#audi .car').droppable({
		//Accepted choice of car which is porsche
		accept: '.choice_Audi' ,
		
		//Drop the client through a function
		drop: function(e, ui) {
		dropclient($(this), ui);
		vDropElement = $(this).closest("#audi .car");
	    
		}
	}); //End of Code for droppable audi clients
	
	//Make clients for bmw, droppable 
	$('#bmw .car').droppable({
		//Accepted choice of car which is porsche
		accept: '.choice_BMW' ,
		
		//Drop the client through a function
		drop: function(e, ui) {
			dropclient($(this), ui);
			vDropElement = $(this).closest("#bmw .car");
			
		}
	}); //End of Code for droppable bmw clients
	
	
	//Make  client's droppable on the exit id of div element
	$('#exit div').droppable({
		//Accepted element of class .client
		accept: '.client' ,
		
		//Creates a drop event which uses a function to drop clients to the exit
		drop: function(e, ui) {
			dropclient2($(this), ui);
			vDropElement = $(this).closest("#bmw .car");
			
			//Removes the client upon client drop on exit with opacity of -80
			removeclient(ui, -80);
		}
		
	}); //end of droppable for exit id of div element
	
	//Make client's droppable on the cashier id of div element
	$('#cashier div').droppable({
		//Accepted element of class .client of selected clients
		accept: '.client.selected' ,
		
		//Creates a drop event which uses a function to drop clients to the exit
		drop: function(e, ui) {
			dropclient2($(this), ui);
			
			
			//Creates a dialog box for interactivity with clients
			$('#dialog').dialog({
			
			height:140,
			modal: true,
				
			
			//Setting the button types
			buttons: {
									//Yes button will use a function to remove the client once the dialog box is closed
									"Yes" : function(){
										//Updates the clients erved to increment of 1
										clients_served = clients_served + 1;
										
										//Updates the car's sold to increment of 1
										cars_sold = cars_sold + 1;
										
										//Calculates the amount by adding the function of calcost to the amount for different car brands
										amount = calcost(ui);
										
										//Updates the fills for cars_sold, clients_served, amount 
										update();
										
										//Removes the client from the car showroom
										removeclient(ui, -150);
										
										
										//Closes the dialog box when yes is pressed
										$ ( this ).dialog( "close" );

										vappendHideElement = $(this).closest(".car").hide();
								
								/*		
								//If client chooses the car with #Porsche

								
									if( '.client.selected' > '.choice_Porsche' + $("#Porsche_1") ){
										//if ($("div[id='porsche']") && ('.client.selected' > '.choice_Porsche')){
									var Porsche1_prop = function(){
								$("#Porsche_1").prop("<img src='images/gold_porsche.jpg' width='120' height='80' alt='Porsche_1'  id='#Porsche_1'/>");
								$(".Porsche1_append").append("<img src='images/sold2.jpg' alt='sold' id='sold' width='80' height='80' margin-top:20px;>");
								$("#Porsche_1").remove()
											
										} 
										
									$(document).ready(function(){
									$("#Porsche_1").append(Porsche1_prop)
									
																			});
								}
									
								
									var Porsche2_prop = function(){
								$("#Porsche_2").prop("<img src='images/gold_porsche.jpg' width='120' height='80' alt='Porsche_2'  id='#Porsche_2'/>");
								$(".Porsche2_append").append("<img src='images/sold2.jpg' alt='sold' id='sold' width='80' height='80' margin-top:20px;>");
								$("#Porsche_2").remove()
											
										} 
										
									$(document).ready(function(){
									$("#Porsche_2").append(Porsche2_prop)
									
																			});
								
									*/
								
                               
										
							
										
			
									
										
									},
				
									//No and Exit button will use a function to remove the client once the dialog box is closed
									"No and Exit": function(){
										
										//Removes the client from the car showroom
										removeclient(ui, -350);
										
										//Closes the dialog box when no and exit is pressed
										$( this ).dialog( "close" );
									}
								},
				close: function() {
					removeclient(ui, -350);
				}
				
			});
			
			
			//var Volkswagen = "choice_Volkswagen"
			//var Audi = "choice_Audi"
			//var BMW = "choice_BMW"
			
			
			
		}
	
		
	}); //end of droppable for cashier id element of div element
	
}); //End of $("document").ready(function() 
